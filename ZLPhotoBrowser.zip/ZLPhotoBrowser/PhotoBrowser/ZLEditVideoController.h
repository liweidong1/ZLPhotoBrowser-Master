//
//  ZLEditVideoController.h
//  ZLPhotoBrowser
//
//  Created by long on 2017/9/15.
//  Copyright © 2017年 long. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZLPhotoModel;

@interface ZLEditVideoController : UIViewController

@property (nonatomic, strong) ZLPhotoModel *model;

@end
